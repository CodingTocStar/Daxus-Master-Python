"""
Función print()

La función print() es una de las más importantes y usadas en el lenguaje de programación Python.
Su función es, básicamente, mostrar mensajes en la pantalla o enviarlos a otros dispositivos, como
enviarlos a archivos de texto.

Con Python 3, la función print es nativa, es decir no tenemos que importarla de alguna librería
para poder utilizarla.

print -> imprimir
"""